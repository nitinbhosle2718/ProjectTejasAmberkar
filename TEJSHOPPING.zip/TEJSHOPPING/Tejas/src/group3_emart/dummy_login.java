package group3_emart;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

public class dummy_login 
{

private String username;
	
private String password;

private int customerid;


@NotEmpty(message="Username can not be empty")
@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "name must contain characters and Digits only")
public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}




@NotEmpty(message="Password cannot be blank")
@Length(min=6,max=14,message="Password should be minimum of ${min} and maximum of ${max}")
@Pattern(regexp = "^[A-Za-z0-9_#@]+$", message = "password must contain characters as well as digits")
public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}



public int getCustomerid() {
	return customerid;
}

public void setCustomerid(int customerid) {
	this.customerid = customerid;
}



public dummy_login()
{
	
}

public dummy_login(String username, String password, int customerid) {
	super();
	this.username = username;
	this.password = password;
	this.customerid = customerid;
}

@Override
public String toString() {
	return "dummy_login [username=" + username + ", password=" + password
			+ ", customerid=" + customerid + "]";
}



	
}
