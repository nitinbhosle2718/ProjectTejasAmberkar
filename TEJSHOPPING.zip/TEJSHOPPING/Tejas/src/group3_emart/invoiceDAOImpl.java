package group3_emart;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;

@Component
public class invoiceDAOImpl implements invoiceDAO
{

	@Autowired
	HibernateTemplate template;
	
	@Override
	public List getInvoice(List prodlist, dummy_login log) 
	{
		// TODO Auto-generated method stub
		

		
		String query="from customer_master where customer_id=?";
		Object[] queryParam = {log.getCustomerid()};
		List list=template.find(query,queryParam);
		
		

		customer_master cust=(customer_master)list.get(0);
		
		List inlist=new ArrayList();
	
		//calculating total
		
		
		
		//invoice purpose
		
		int cust_old_epoints=cust.getEpoints();
		int epoint_credit=0;
		int epoint_redeem=0;
		int cust_final_epoint;
		int total=0;
		int tax;
		
		
		
		//calculation purpose
		int prodepoints=0;
		int price;
		int quantity;
		
		
	
		Iterator it=prodlist.iterator();
		
		
		while(it.hasNext())
		{
			
			
			product_master product=(product_master)it.next();
			
			prodepoints=product.getProduct_epoints();
			quantity=Integer.parseInt(product.getProduct_quantity());
			
			if(cust.getCard_holder().equals("no"))
			{
				price=product.getProduct_price()*quantity;
				product.setConsidered_price(price);
				total=total+price;
				
			}
			else if(product.getEpoints_checked().equals("no"))
			{
				
				
				if(product.getProduct_discount().equals("yes"))
				{
					
					price=Integer.parseInt(product.getProduct_discounted_price())*quantity;
					
					product.setConsidered_price(price);
					total=total+price;
					
				}
				else
				{
					
					price=product.getProduct_price()*quantity;
					product.setConsidered_price(price);
					total=total+price;
					
					
				}
			}
			else
			{
				product.setConsidered_price(prodepoints*quantity);
				epoint_redeem=epoint_redeem+prodepoints*quantity;	
				
			}
			
			
			
		}
		
		
		
		//returning if epoints not sufficient
		
		epoint_credit=(total*5/100);
		
		if(cust_old_epoints>=epoint_redeem)
		{
			cust_final_epoint=cust_old_epoints-epoint_redeem;
			cust_final_epoint=cust_final_epoint+epoint_credit;
			cust.setEpoints(cust_final_epoint);			
		}
		else
		{
			return inlist;
		}
		
		
		
		
		tax=total*4/100;
		
		total=total+tax;
		
		
		invoice_header inheader=new invoice_header();
		
		inheader.setCustomer_master_id(cust);
		inheader.setDelivery_house_number(cust.getHouse_number());
		inheader.setDelivery_street_name(cust.getStreet_name());
		inheader.setDelivery_city(cust.getCity());
		inheader.setDelivery_pincode(Integer.parseInt(cust.getPincode()));
		inheader.setDelivery_state(cust.getState());
		inheader.setDate(new Date());
		inheader.setEpoints_credited(epoint_credit);
		inheader.setEpoints_redeemed(epoint_redeem);
		inheader.setTax(tax);
		inheader.setTotal(total);
		inheader.setTotal_epoints(cust_final_epoint);
		inheader.setCustname(cust.getFirst_name()+" "+cust.getLast_name());
		template.save(inheader);
		
		
		
		it=prodlist.iterator();
		
		int num=1;
		
		while(it.hasNext())
		{
			
			
		product_master product=(product_master)it.next();
			
		invoice_detail indetail=new invoice_detail();
		
		indetail.setDiscounted_price(product.getProduct_discounted_price());
		indetail.setEpoints(product.getProduct_epoints());
		indetail.setInvoice_header_number(inheader);
		indetail.setPrice(product.getProduct_price());
		indetail.setProduct_master_id(product);
		indetail.setProduct_name(product.getProduct_name());
		indetail.setSerial_number(num);
		num++;
		
		template.save(indetail);
		
		}
		
		
		template.update(cust);
		
		
		inlist.add(inheader);
		inlist.add(cust_old_epoints);
		inlist.add(cust);
		
		return inlist;
	}
	
	

}
