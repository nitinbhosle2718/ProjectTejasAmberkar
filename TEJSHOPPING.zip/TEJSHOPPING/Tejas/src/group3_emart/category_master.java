package group3_emart;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(uniqueConstraints={@UniqueConstraint(columnNames={"category_id","subcategory_id"})})
public class category_master 
{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int category_master_id;
	
	
	
	@Column(name="category_id")
	private String category_id;
	
	
	
	@Column(name="subcategory_id")
	private String subcategory_id;
	
	
	
	private String category_name;
	
	
	
	private String image_url;
	
	
	
	private String final_product;
	
	
	
	

	public int getCategory_master_id() {
		return category_master_id;
	}

	
	
	public void setCategory_master_id(int category_master_id) {
		this.category_master_id = category_master_id;
	}

	
	
	public String getCategory_id() {
		return category_id;
	}

	
	
	public void setCategory_id(String category_id) {
		this.category_id = category_id;
	}

	
	
	public String getSubcategory_id() {
		return subcategory_id;
	}

	
	
	public void setSubcategory_id(String subcategory_id) {
		this.subcategory_id = subcategory_id;
	}

	
	
	public String getCategory_name() {
		return category_name;
	}

	
	
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	
	
	public String getImage_url() {
		return image_url;
	}

	
	
	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}

	
	
	public String getFinal_product() {
		return final_product;
	}

	
	
	public void setFinal_product(String final_product) {
		this.final_product = final_product;
	}


	
	
	public category_master()
	{
		
	}
	
	

	public category_master(int category_master_id, String category_id,
			String subcategory_id, String category_name, String image_url,
			String final_product) {
		super();
		this.category_master_id = category_master_id;
		this.category_id = category_id;
		this.subcategory_id = subcategory_id;
		this.category_name = category_name;
		this.image_url = image_url;
		this.final_product = final_product;
	}


	
	

	@Override
	public String toString() {
		return "category_master [category_master_id=" + category_master_id
				+ ", category_id=" + category_id + ", subcategory_id="
				+ subcategory_id + ", category_name=" + category_name
				+ ", image_url=" + image_url + ", final_product="
				+ final_product + "]";
	}
	
	
	
	
	
	
}
