package group3_emart;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/invoicepdf.do")
public class InvoicePdfController 
{

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView before(HttpSession session)
	{
		//session.getAttribute("inheader");
		List pdflist=new ArrayList();
		
		
		pdflist.add(session.getAttribute("oldepoints"));
		
		pdflist.add(session.getAttribute("inheader"));
		
		pdflist.add(session.getAttribute("customer"));
		
		pdflist.add(session.getAttribute("myproduct"));
		
		session.invalidate();
	return new ModelAndView("pdfView","pdflist",pdflist);
	}
	
}
