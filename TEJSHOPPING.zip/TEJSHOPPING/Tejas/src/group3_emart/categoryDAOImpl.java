package group3_emart;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;
@Component
public class categoryDAOImpl implements categoryDAO
{
	@Autowired
	private HibernateTemplate template;
	@Override
	public List getCategories(String categoryid,String subcategoryid) 
	{
	
		
		// TODO Auto-generated method stub
		if(categoryid==null&&subcategoryid==null)
		{
		String query="from category_master where subcategory_id='0'";  
		List list=template.find(query);
		return list;
		}
		else if(subcategoryid.equals("0"))
		{
			String query="from category_master where category_id=? and not subcategory_id='0'";
			Object[] queryParam = {categoryid};
			List list=template.find(query,queryParam);
			return list;
		}
		else
		{
			String query="from category_master where category_id=?";
			Object[] queryParam = {subcategoryid};
		    List list=template.find(query,queryParam);
			return list;
		}
	}

}
