package group3_emart;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;

@Component
public class productDAOImpl implements productDAO
{
	
	@Autowired
	private HibernateTemplate template;

	@Override
	public List getProducts(String subcategoryid) 
	{
		// TODO Auto-generated method stub
		
		String query="from product_master where sub_category_id=?";  
		Object[] queryParam = {subcategoryid};
		List list=template.find(query,queryParam);
		return list;
		
	}

	@Override
	public product_master getProduct(String productid) {
		// TODO Auto-generated method stub
		
		String query="from product_master where product_id=?";  
		Object[] queryParam = {Integer.parseInt(productid)};
		List list=template.find(query,queryParam);

		return (product_master)list.get(0);
	}

	
}
