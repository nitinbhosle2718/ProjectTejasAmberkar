package group3_emart;

import java.util.List;

public interface categoryDAO 
{
List getCategories(String categoryid,String subcategoryid);
}
