package group3_emart;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

@Entity
public class product_master 
{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int product_id;
	
	@Transient
	private String epoints_checked="no";
	
	
	
	@Transient
	private String product_quantity;
	
	
	
	
	@Transient
	private int considered_price;
	
	
	
	
	private String sub_category_id;
	
	
	
	private String product_name;
	
	
	
	private String model_number;
	
	
	
	@Column(length=1000)
	private String product_description;
	
	
	
	private String product_brand;
	
	
	
	private int product_price;
	
	
	
	private String product_discount;
	
	
	private String product_discounted_price;
	
	
	@Column(nullable=true)
	private int product_epoints;
	
	
	
	private int product_availability;
	
	
	
	
	
	
	
	
	
	
	
	



	public String getProduct_quantity() {
		return product_quantity;
	}





	public void setProduct_quantity(String product_quantity) {
		this.product_quantity = product_quantity;
	}





	public int getConsidered_price() {
		return considered_price;
	}





	public void setConsidered_price(int considered_price) {
		this.considered_price = considered_price;
	}





	@Column(length=150)
	private String product_image_url;

	
	
	
	
	public int getProduct_id() {
		return product_id;
	}





	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}





	public String getSub_category_id() {
		return sub_category_id;
	}





	public void setSub_category_id(String sub_category_id) {
		this.sub_category_id = sub_category_id;
	}





	public String getProduct_name() {
		return product_name;
	}





	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}





	public String getModel_number() {
		return model_number;
	}





	public void setModel_number(String model_number) {
		this.model_number = model_number;
	}





	public String getProduct_description() {
		return product_description;
	}





	public void setProduct_description(String product_description) {
		this.product_description = product_description;
	}





	public String getProduct_brand() {
		return product_brand;
	}





	public void setProduct_brand(String product_brand) {
		this.product_brand = product_brand;
	}





	public int getProduct_price() {
		return product_price;
	}





	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}







	public String getProduct_discount() {
		return product_discount;
	}





	public void setProduct_discount(String product_discount) {
		this.product_discount = product_discount;
	}





	public String getProduct_discounted_price() {
		return product_discounted_price;
	}





	public void setProduct_discounted_price(String product_discounted_price) {
		this.product_discounted_price = product_discounted_price;
	}





	public int getProduct_epoints() {
		return product_epoints;
	}





	public void setProduct_epoints(int product_epoints) {
		this.product_epoints = product_epoints;
	}





	public int getProduct_availability() {
		return product_availability;
	}





	public void setProduct_availability(int product_availability) {
		this.product_availability = product_availability;
	}





	public String getProduct_image_url() {
		return product_image_url;
	}





	public void setProduct_image_url(String product_image_url) {
		this.product_image_url = product_image_url;
	}





	public String getEpoints_checked() {
		return epoints_checked;
	}





	public void setEpoints_checked(String epoints_checked) {
		this.epoints_checked = epoints_checked;
	}





	public product_master()
	{
		
	}





	public product_master(int product_id, String epoints_checked,
			String product_quantity, int considered_price,
			String sub_category_id, String product_name, String model_number,
			String product_description, String product_brand,
			int product_price, String product_discount,
			String product_discounted_price, int product_epoints,
			int product_availability, String product_image_url) {
		super();
		this.product_id = product_id;
		this.epoints_checked = epoints_checked;
		this.product_quantity = product_quantity;
		this.considered_price = considered_price;
		this.sub_category_id = sub_category_id;
		this.product_name = product_name;
		this.model_number = model_number;
		this.product_description = product_description;
		this.product_brand = product_brand;
		this.product_price = product_price;
		this.product_discount = product_discount;
		this.product_discounted_price = product_discounted_price;
		this.product_epoints = product_epoints;
		this.product_availability = product_availability;
		this.product_image_url = product_image_url;
	}





	@Override
	public String toString() {
		return "product_master [product_id=" + product_id
				+ ", epoints_checked=" + epoints_checked
				+ ", product_quantity=" + product_quantity
				+ ", considered_price=" + considered_price
				+ ", sub_category_id=" + sub_category_id + ", product_name="
				+ product_name + ", model_number=" + model_number
				+ ", product_description=" + product_description
				+ ", product_brand=" + product_brand + ", product_price="
				+ product_price + ", product_discount=" + product_discount
				+ ", product_discounted_price=" + product_discounted_price
				+ ", product_epoints=" + product_epoints
				+ ", product_availability=" + product_availability
				+ ", product_image_url=" + product_image_url + "]";
	}





	


	
}
