package group3_emart;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/registration.do")
public class registrationController
{
	
	@Autowired
	RegisterDAO regdao;
	
	List <String>Statelist;
	List <String>Citylist;

		@RequestMapping(method = RequestMethod.GET)
		public ModelAndView before()
		{
	 		customer_master customer=new customer_master();
			return new ModelAndView("Registration.definition","reg",customer);
		}
		
		
		
		
		@RequestMapping(method = RequestMethod.POST)
		public String afterSubmit(
			@Valid @ModelAttribute("reg") customer_master newcustomer,BindingResult result) 
		{
			//return form success view
			if(result.hasErrors())
			{
				return "Registration.definition";
			}
			else
			{
				if(newcustomer.getCard_holder().equals("yes"))
					newcustomer.setEpoints(50);
				
			regdao.saveCustomer(newcustomer);
			return "redirect:/login.do";
			}
		}
		
		
		
		
		
		@ModelAttribute("CityList")
		public List<String> populateWebFrameworkList1() 
		{
			Citylist=new ArrayList<String>();
			Citylist.add("");
			Citylist.add("Hyderabad");
			Citylist.add("Vishakapatnam");
			Citylist.add("Itanagar");
			Citylist.add("Dispur");
			Citylist.add("Patna");
			Citylist.add("Punjab");
			Citylist.add("Panji");
			Citylist.add("Surat");
			Citylist.add("Ahmedabad");
			Citylist.add("Chandigarh");
			Citylist.add("Gandhinagar");
			Citylist.add("Shimla");
			Citylist.add("Surat");
			Citylist.add("Ahmedabad");
			Citylist.add("Chandigarh");
			Citylist.add("Gandhinagar");
			Citylist.add("Shimla");
			Citylist.add("Srinagar");
			Citylist.add("Ranchi");
			Citylist.add("Bengaluru");
			Citylist.add("Thiruvananthapuram");
			Citylist.add("Bhopal");
			Citylist.add("Mumbai");
			Citylist.add("Nagpur");
			Citylist.add("Imphal");
			Citylist.add("Shillong");
			Citylist.add("kohima");
			Citylist.add("Aizawl");
			Citylist.add("Bhubaneswar");
			Citylist.add("Jaipur");
			Citylist.add("Gangtok");
			Citylist.add("Chennai");
			Citylist.add("Hyderabad");
			Citylist.add("Agartala");
			Citylist.add("Lucknow");
			Citylist.add("Dehradun");
			Citylist.add("Lucknow");
			return Citylist;
		
		}
		
		
		
		@ModelAttribute("StateList")
		public List<String> populateWebFrameworkList() 
		{
			Statelist=new ArrayList<String>();
			Statelist.add("");
			Statelist.add("Andhra Pradesh");
			Statelist.add("Arunachal Pradesh");
			Statelist.add("Assam");
			Statelist.add("	Bihar");
			Statelist.add("Chandigarh");
			Statelist.add("Chhattisgarh");
			Statelist.add("Goa");
			Statelist.add("Gujarat");
			Statelist.add("Haryana");
			Statelist.add("Himachal Pradesh");
			Statelist.add("Jammu and Kashmir");
			Statelist.add("Jharkhand");
			Statelist.add("Karnataka");
			Statelist.add("Kerala");
			Statelist.add("Madhya Pradesh");
			Statelist.add("Maharashtra");
			Statelist.add("Manipur");
			Statelist.add("Meghalaya");
			Statelist.add("Mizoram");
			Statelist.add("Nagaland");
			Statelist.add("Odisha");
			Statelist.add("Punjab");
			Statelist.add("Rajasthan");
			Statelist.add("Sikkim");
			Statelist.add("Tamil Nadu");
			Statelist.add("Telangana");
			Statelist.add("Tripura");
			Statelist.add("Uttar Pradesh");
			Statelist.add("Uttarakhand");
			Statelist.add("West Bengal");
			
		return Statelist;
		}
		
		
		
		

}
