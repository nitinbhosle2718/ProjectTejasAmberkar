package group3_emart;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/category")
public class categorycontroller 
{
	@Autowired
	categoryDAO cdao;
	
	@Autowired
	productDAO pdao;
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView before(HttpServletRequest request,HttpSession session)
	{
		
		
		String categoryid=request.getParameter("category");
		String subcategoryid=request.getParameter("subcategory");
		String finalprod=request.getParameter("finalprod");
		
		
		
		if(finalprod==null||finalprod.equals("no"))
		{
			
			//category display (category table)
			
			List list=cdao.getCategories(categoryid,subcategoryid);		
			return new ModelAndView("category.definition","categories",list);
			
		}
		else
		{
			String productid=request.getParameter("productid");
			
			if(productid==null)
			{
				//final category (caegory table)
			
				List list=pdao.getProducts(subcategoryid);
				
				/*Iterator it;
						
				int price;
			
				Integer discount;
			
				it=list.iterator();
				while(it.hasNext())
				{
					product_master prod=(product_master)it.next();
					
					
					if(prod.getProduct_discount().equals("yes"))
					{
						price=prod.getProduct_price();
					
						discount=price-(price*5/100);
					
						prod.setProduct_discounted_price(discount.toString());
					}
					
					
				}
				*/
				
				session.setAttribute("productlist",list);
			
				return new ModelAndView("product.definition","products",list);
				
				
				}
			
			else
			{
				
			
				//product display (product table)
				
				product_master prod=pdao.getProduct(productid);
				
				int price;
				
				Integer discount;
				
				if(prod.getProduct_discount().equals("yes"))
				{
				price=prod.getProduct_price();
				
				discount=price-(price*5/100);
			
				prod.setProduct_discounted_price(discount.toString());
				}
				
				if(prod.getProduct_epoints()==0)
					return new ModelAndView("productdetail.definition","product",prod);
				else
					return new ModelAndView("productdetailepoints.definition","product",prod);	
				
				
			}
				
		}
		
		
	}
	
	
	
	
	@ModelAttribute("QuantityList")
	public List<String> populateWebFrameworkList1() 
	{
		List list=new ArrayList<String>();
		list.add("1");
		list.add("2");
		list.add("3");
		list.add("4");
		list.add("5");
		list.add("6");
		list.add("7");
		list.add("8");
		list.add("9");
		list.add("10");
		return list;
	}
	
	
	
	
}
