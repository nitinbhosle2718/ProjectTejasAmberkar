package group3_emart;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;

@Component
public class LoginDAOImpl implements LoginDAO
{
	@Autowired
	private HibernateTemplate template;
	@Override
	public dummy_login checkLogin(dummy_login ref)
	{
		// TODO Auto-generated method stub
		String query="from customer_master where username=? and password=?";
		Object[] queryParam={ref.getUsername(),ref.getPassword()};
		List list=template.find(query,queryParam);
		
		customer_master cust;
		
		try
		{
			cust=(customer_master)list.get(0);	
		}
		catch(Exception e)
		{
			ref.setCustomerid(0);
			return ref;
		}
			
		ref.setCustomerid(cust.getCustomer_id());
		return ref;

	}

}
