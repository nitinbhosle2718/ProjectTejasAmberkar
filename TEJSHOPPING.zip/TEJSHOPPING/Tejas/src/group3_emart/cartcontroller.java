package group3_emart;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/cart")
public class cartcontroller 
{
	
	
	//removing from cart
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView before(HttpServletRequest request,HttpSession session)
	{
		String str=request.getParameter("main");
		
		if(str==null)			
		{
			
			int productid=Integer.parseInt(request.getParameter("productid"));
			
			List productlist=(List)session.getAttribute("myproduct");
			
			
			Iterator it=productlist.iterator();
			
			while(it.hasNext())
			{
				product_master prod=(product_master)it.next();
				
				if(prod.getProduct_id()==productid)
				{
					productlist.remove(prod);
					break;
				}
			}
			
			try
			{
				productlist.get(0);
			}
			catch(Exception e)
			{
				return new ModelAndView("redirect:/category.do");
			}
			
			session.setAttribute("myproduct",productlist);
			
			return new ModelAndView("cart.definition","cartproducts",productlist);
		
		}
		else
		{
			List productlist=(List)session.getAttribute("myproduct");
			return new ModelAndView("cart.definition","cartproducts",productlist);
		}
	}
	
	
	
	
	
	
	//adding to cart
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView before(HttpServletRequest request,HttpSession session,product_master product)
	{
		
		
		
		if(session.getAttribute("login")==null)
		{
			return new ModelAndView("redirect:/login.do");
		}
		
		
		
		List cartlist=new ArrayList();

			
		if(session.getAttribute("myproduct")!=null)
		{
			cartlist=(List)session.getAttribute("myproduct");
		}
		
		List productlist=(List)session.getAttribute("productlist");
		
		int productid=Integer.parseInt(request.getParameter("productid"));
		
		Iterator it=productlist.iterator();
		
		int price;
		Integer discount;
		
		while(it.hasNext())
		{
			product_master prod=(product_master)it.next();
			
			if(prod.getProduct_id()==productid)
			{
				prod.setEpoints_checked(product.getEpoints_checked());
				prod.setProduct_quantity(product.getProduct_quantity());
				
				if(prod.getProduct_discount().equals("yes"))
				{
				price=prod.getProduct_price();
				
				discount=price-(price*5/100);
			
				prod.setProduct_discounted_price(discount.toString());
				}
				
				boolean present=false;
				
				Iterator cartit=cartlist.iterator();
				while(cartit.hasNext())
				{
					product_master prod1=(product_master)cartit.next();
				
					if(prod1.getProduct_id()==productid)
					{
						present=true;
						break;
					}
				}
				
				
				if(present==false)
				{
					cartlist.add(prod);
					session.setAttribute("myproduct",cartlist);
				}
			}
		}
		
		
		
		return new ModelAndView("cart.definition","cartproducts",cartlist);
	}
	
	
	
	
}
