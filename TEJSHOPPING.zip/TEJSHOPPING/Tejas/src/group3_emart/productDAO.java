package group3_emart;

import java.util.List;

public interface productDAO 
{
	List getProducts(String subcategoryid);
	
	product_master getProduct(String productid);
}
