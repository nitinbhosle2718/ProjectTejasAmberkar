package group3_emart;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;



@Entity
public class invoice_header 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int invoice_number;
	
	
	@ManyToOne
	@JoinColumn(name="customer_id")
	private customer_master customer_master_id;
	
	private  String custname;
	public String getCustname() {
		return custname;
	}







	public void setCustname(String custname) {
		this.custname = custname;
	}







	private Date date;
	
	//not required
	private String billing_address;
	
	
	
	private String delivery_house_number;
	
	
	
	private String delivery_street_name;
	
	
	private String delivery_city;
	
	
	
	private String delivery_state;
	
	
	private int delivery_pincode;
	
	
	
	private double tax;
	
	
	private double total;
	
	

	private int epoints_credited;
	

	private int epoints_redeemed;
	
	
	private int total_epoints;


	

	
	
	
	public int getInvoice_number() {
		return invoice_number;
	}







	public void setInvoice_number(int invoice_number) {
		this.invoice_number = invoice_number;
	}







	public customer_master getCustomer_master_id() {
		return customer_master_id;
	}







	public void setCustomer_master_id(customer_master customer_master_id) {
		this.customer_master_id = customer_master_id;
	}







	public Date getDate() {
		return date;
	}







	public void setDate(Date date) {
		this.date = date;
	}







	public String getBilling_address() {
		return billing_address;
	}







	public void setBilling_address(String billing_address) {
		this.billing_address = billing_address;
	}







	public String getDelivery_house_number() {
		return delivery_house_number;
	}







	public void setDelivery_house_number(String delivery_house_number) {
		this.delivery_house_number = delivery_house_number;
	}







	public String getDelivery_street_name() {
		return delivery_street_name;
	}







	public void setDelivery_street_name(String delivery_street_name) {
		this.delivery_street_name = delivery_street_name;
	}







	public String getDelivery_city() {
		return delivery_city;
	}







	public void setDelivery_city(String delivery_city) {
		this.delivery_city = delivery_city;
	}







	public String getDelivery_state() {
		return delivery_state;
	}







	public void setDelivery_state(String delivery_state) {
		this.delivery_state = delivery_state;
	}







	public int getDelivery_pincode() {
		return delivery_pincode;
	}







	public void setDelivery_pincode(int delivery_pincode) {
		this.delivery_pincode = delivery_pincode;
	}







	public double getTax() {
		return tax;
	}







	public void setTax(double tax) {
		this.tax = tax;
	}







	public double getTotal() {
		return total;
	}







	public void setTotal(double total) {
		this.total = total;
	}







	public int getEpoints_credited() {
		return epoints_credited;
	}







	public void setEpoints_credited(int epoints_credited) {
		this.epoints_credited = epoints_credited;
	}







	public int getEpoints_redeemed() {
		return epoints_redeemed;
	}







	public void setEpoints_redeemed(int epoints_redeemed) {
		this.epoints_redeemed = epoints_redeemed;
	}







	public int getTotal_epoints() {
		return total_epoints;
	}







	public void setTotal_epoints(int total_epoints) {
		this.total_epoints = total_epoints;
	}







	public invoice_header()
	{
		
	}







	public invoice_header(int invoice_number,
			customer_master customer_master_id, Date date,
			String billing_address, String delivery_house_number,
			String delivery_street_name, String delivery_city,
			String delivery_state, int delivery_pincode, double tax,
			double total, int epoints_credited, int epoints_redeemed,
			int total_epoints) {
		super();
		this.invoice_number = invoice_number;
		this.customer_master_id = customer_master_id;
		this.date = date;
		this.billing_address = billing_address;
		this.delivery_house_number = delivery_house_number;
		this.delivery_street_name = delivery_street_name;
		this.delivery_city = delivery_city;
		this.delivery_state = delivery_state;
		this.delivery_pincode = delivery_pincode;
		this.tax = tax;
		this.total = total;
		this.epoints_credited = epoints_credited;
		this.epoints_redeemed = epoints_redeemed;
		this.total_epoints = total_epoints;
	}







	@Override
	public String toString() {
		return "invoice_header [invoice_number=" + invoice_number + ", customer_master_id=" + customer_master_id
				+ ", custname=" + custname + ", date=" + date + ", billing_address=" + billing_address
				+ ", delivery_house_number=" + delivery_house_number + ", delivery_street_name=" + delivery_street_name
				+ ", delivery_city=" + delivery_city + ", delivery_state=" + delivery_state + ", delivery_pincode="
				+ delivery_pincode + ", tax=" + tax + ", total=" + total + ", epoints_credited=" + epoints_credited
				+ ", epoints_redeemed=" + epoints_redeemed + ", total_epoints=" + total_epoints + "]";
	}







	
	
	
	
	
	
	

	
}
