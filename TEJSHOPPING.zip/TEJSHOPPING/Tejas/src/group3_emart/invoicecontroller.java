package group3_emart;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/invoice")
public class invoicecontroller 
{
	
	@Autowired
	invoiceDAO invoice;
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView before(HttpServletRequest request,HttpSession session,ModelMap model)
	{
		
		List productlist=(List)session.getAttribute("myproduct");
		
		dummy_login log=(dummy_login)session.getAttribute("login");
		
		List invoicelist=invoice.getInvoice(productlist,log);
		
		try
		{
			session.setAttribute("inheader",invoicelist.get(0));
		}
		catch(Exception e)
		{
			String ob="Insufficient epoints";
			model.addAttribute("errmsg",ob);
			return new ModelAndView("cart.definition","cartproducts",productlist);
		}
		
		session.setAttribute("oldepoints",invoicelist.get(1));
		session.setAttribute("customer",invoicelist.get(2));
		
		
		return new ModelAndView("invoice.definition");
	}
}
