package group3_emart;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;

@Entity
public class customer_master 
{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customer_id;
	
	

	private String first_name;
	
	
	
	private String last_name;
	
	
	
	private String house_number;
	
	
	
	private String street_name;
	
	
	
	private String city;
	
	
	
	private String state;
	
	
	
	private String pincode;
	
	
	
	private String contact_number;
	
	
	
	private String card_holder;
	
	
	private int epoints;
	

	private String email;
	

	private String username;
	
	

	private String password;

	
	
	
	
	
	
	
	
	public int getCustomer_id() {
		return customer_id;
	}









	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}








	@NotEmpty(message="first name can not be empty")
	public String getFirst_name() {
		return first_name;
	}









	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}








	@NotEmpty(message=" last name can not be empty")
	public String getLast_name() {
		return last_name;
	}









	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}








	@NotEmpty(message="house number can not be empty")
	public String getHouse_number() {
		return house_number;
	}









	public void setHouse_number(String house_number) {
		this.house_number = house_number;
	}








	@NotEmpty(message="street name can not be empty")
	public String getStreet_name() {
		return street_name;
	}









	public void setStreet_name(String street_name) {
		this.street_name = street_name;
	}








	@NotEmpty(message="city name can not be empty")
	public String getCity() {
		return city;
	}









	public void setCity(String city) {
		this.city = city;
	}








	@NotEmpty(message=" state name can not be empty")
	public String getState() {
		return state;
	}









	public void setState(String state) {
		this.state = state;
	}







	
	

	@NotEmpty(message="Please Enter pincode")
	@Pattern(regexp="[0-9]{6}",message="pincode must be 6 digit")
	public String getPincode() {
		return pincode;
	}









	public void setPincode(String pincode) {
		this.pincode = pincode;
	}







	@NotEmpty(message="Please Enter contact number")
	@Pattern(regexp="[0-9]{10}",message="contact number must be 10 digit")
	public String getContact_number() {
		return contact_number;
	}









	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}









	@NotEmpty(message="Please select a box")
	public String getCard_holder() {
		return card_holder;
	}









	public void setCard_holder(String card_holder) {
		this.card_holder = card_holder;
	}









	public int getEpoints() {
		return epoints;
	}









	public void setEpoints(int epoints) {
		this.epoints = epoints;
	}







	@NotEmpty(message="Please Enter Your Email Id")
	@Email(message="invalid email id")
	public String getEmail() {
		return email;
	}









	public void setEmail(String email) {
		this.email = email;
	}








	@NotEmpty(message="Username can not be empty")
	@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "name must contain characters and Digits only")
	public String getUsername() {
		return username;
	}









	public void setUsername(String username) {
		this.username = username;
	}








	@NotEmpty(message="Password cannot be blank")
	@Length(min=6,max=14,message="Password should be minimum of ${min} and maximum of ${max}")
	@Pattern(regexp = "^[A-Za-z0-9_#@]+$", message = "password must contain characters as well as digits")
	public String getPassword() {
		return password;
	}









	public void setPassword(String password) {
		this.password = password;
	}









	public customer_master()
	{
		
	}









	@Override
	public String toString() {
		return "customer_master [customer_id=" + customer_id + ", first_name="
				+ first_name + ", last_name=" + last_name + ", house_number="
				+ house_number + ", street_name=" + street_name + ", city="
				+ city + ", state=" + state + ", pincode=" + pincode
				+ ", contact_number=" + contact_number + ", card_holder="
				+ card_holder + ", epoints=" + epoints + ", email=" + email
				+ ", username=" + username + ", password=" + password + "]";
	}









	public customer_master(int customer_id, String first_name,
			String last_name, String house_number, String street_name,
			String city, String state, String pincode, String contact_number,
			String card_holder, int epoints, String email, String username,
			String password) {
		super();
		this.customer_id = customer_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.house_number = house_number;
		this.street_name = street_name;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.contact_number = contact_number;
		this.card_holder = card_holder;
		this.epoints = epoints;
		this.email = email;
		this.username = username;
		this.password = password;
	}
















	
}
