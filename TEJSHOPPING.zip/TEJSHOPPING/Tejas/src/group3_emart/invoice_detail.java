package group3_emart;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(uniqueConstraints={@UniqueConstraint(columnNames={"invoice_number","serial_number"})})
public class invoice_detail 
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int invoice_detail_id;
	
	@ManyToOne
	@JoinColumn(name="invoice_number")
	private invoice_header invoice_header_number;
	
	
	@ManyToOne
	@JoinColumn(name="product_id")
	private product_master product_master_id;
	
	
	
	private String product_name;
	
	
	
	@Column(name="serial_number")
	private int serial_number;
	
	
	private int quantity;
	
	
	private int price;
	
	
	private String discounted_price;
	
	
	private int epoints;


	
	
	
	
	public String getDiscounted_price() {
		return discounted_price;
	}



	public void setDiscounted_price(String discounted_price) {
		this.discounted_price = discounted_price;
	}



	public int getInvoice_detail_id() {
		return invoice_detail_id;
	}


	
	public void setInvoice_detail_id(int invoice_detail_id) {
		this.invoice_detail_id = invoice_detail_id;
	}

	

	public invoice_header getInvoice_header_number() {
		return invoice_header_number;
	}

	

	public void setInvoice_header_number(invoice_header invoice_header_number) {
		this.invoice_header_number = invoice_header_number;
	}

	

	public product_master getProduct_master_id() {
		return product_master_id;
	}


	
	public void setProduct_master_id(product_master product_master_id) {
		this.product_master_id = product_master_id;
	}


	
	public String getProduct_name() {
		return product_name;
	}


	
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}


	
	public int getSerial_number() {
		return serial_number;
	}


	
	public void setSerial_number(int serial_number) {
		this.serial_number = serial_number;
	}


	
	public int getQuantity() {
		return quantity;
	}


	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	
	public int getPrice() {
		return price;
	}


	
	public void setPrice(int price) {
		this.price = price;
	}


	
	public int getEpoints() {
		return epoints;
	}


	
	public void setEpoints(int epoints) {
		this.epoints = epoints;
	}


	
	public invoice_detail()
	{
		
	}



	public invoice_detail(int invoice_detail_id,
			invoice_header invoice_header_number,
			product_master product_master_id, String product_name,
			int serial_number, int quantity, int price,
			String discounted_price, int epoints) {
		super();
		this.invoice_detail_id = invoice_detail_id;
		this.invoice_header_number = invoice_header_number;
		this.product_master_id = product_master_id;
		this.product_name = product_name;
		this.serial_number = serial_number;
		this.quantity = quantity;
		this.price = price;
		this.discounted_price = discounted_price;
		this.epoints = epoints;
	}



	@Override
	public String toString() {
		return "invoice_detail [invoice_detail_id=" + invoice_detail_id
				+ ", invoice_header_number=" + invoice_header_number
				+ ", product_master_id=" + product_master_id
				+ ", product_name=" + product_name + ", serial_number="
				+ serial_number + ", quantity=" + quantity + ", price=" + price
				+ ", discounted_price=" + discounted_price + ", epoints="
				+ epoints + "]";
	}
	
	
	
	
	
	
	
}
