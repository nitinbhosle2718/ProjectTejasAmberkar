package group3_emart;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;



public class PDFView extends AbstractPdfView {
 protected void buildPdfDocument(Map model,
   Document document, PdfWriter writer, HttpServletRequest req,
   HttpServletResponse resp) throws Exception {
  
  List pdflist = (List) model.get("pdflist");
  
  Paragraph title = new Paragraph(new Chunk("                        INVOICE",FontFactory.getFont(FontFactory.HELVETICA, 30)));
  document.add(title);
  document.add(Chunk.NEWLINE);
  
  
  customer_master customer=(customer_master)pdflist.get(2);
  Paragraph by1 = new Paragraph(new Chunk(customer.getFirst_name()+" "+customer.getLast_name(),FontFactory.getFont(FontFactory.HELVETICA, 15)));
  
  invoice_header inheader=(invoice_header)pdflist.get(1);
  //Paragraph by2 = new Paragraph(new Chunk("Billing Address : ",FontFactory.getFont(FontFactory.HELVETICA, 20)));
  Paragraph by3 = new Paragraph(new Chunk(inheader.getDelivery_house_number()+" "+inheader.getDelivery_street_name(),FontFactory.getFont(FontFactory.HELVETICA, 10)));
  Paragraph by4 = new Paragraph(new Chunk(inheader.getDelivery_city(),FontFactory.getFont(FontFactory.HELVETICA, 10)));
  Paragraph by5 = new Paragraph(new Chunk(inheader.getDelivery_state(),FontFactory.getFont(FontFactory.HELVETICA, 10)));
  Paragraph by6 = new Paragraph(new Chunk("Pincode : "+inheader.getDelivery_pincode(),FontFactory.getFont(FontFactory.HELVETICA, 10)));
  document.add(by1);
  //document.add(by2);
  document.add(by3);
  document.add(by4);
  document.add(by5);
  document.add(by6);
  document.add(Chunk.NEWLINE);
  document.add(Chunk.NEWLINE);
  Paragraph by8 = new Paragraph(new Chunk("Card Holder : "+customer.getCard_holder(),FontFactory.getFont(FontFactory.HELVETICA, 15)));
  document.add(by8);
  document.add(Chunk.NEWLINE);
  List cartlist=(List)pdflist.get(3);
  Paragraph by7 = new Paragraph(new Chunk("Product"+"  "+"Price"+"  "+"Discounted Price"+"  "+"Epoints"+"  "+"Opted for Epoints"+"  "+"Qty"+"  "+"Final price",FontFactory.getFont(FontFactory.HELVETICA, 13)));
  document.add(by7);
  document.add(Chunk.NEWLINE);
  Iterator itr=cartlist.iterator();
  String product=null;
  while(itr.hasNext())
  {
	 
	  
	 
	  
		  product_master prod=(product_master) itr.next();
		  product=prod.getProduct_name()+"  "+prod.getProduct_price()+"                       "+prod.getProduct_discounted_price()+"                     "+prod.getProduct_epoints()+"                       "+prod.getEpoints_checked()+"                            "+prod.getProduct_quantity()+"              "+prod.getConsidered_price();
		  Paragraph by9 = new Paragraph(new Chunk(product,FontFactory.getFont(FontFactory.HELVETICA, 10))); 
		  document.add(by9);
	  
	  
}
  
  
  
  
  document.add(Chunk.NEWLINE);
  document.add(Chunk.NEWLINE);
  document.add(Chunk.NEWLINE);
  document.add(Chunk.NEWLINE);
  document.add(Chunk.NEWLINE);
  document.add(Chunk.NEWLINE);
  document.add(Chunk.NEWLINE);
  document.add(Chunk.NEWLINE);
  document.add(Chunk.NEWLINE);
  double tax=inheader.getTax();
  Paragraph by10 = new Paragraph(new Chunk("                                                                                       "+"Tax : "+tax,FontFactory.getFont(FontFactory.HELVETICA, 15)));
  document.add(by10);
  double total=inheader.getTotal();
  Paragraph by11 = new Paragraph(new Chunk("                                                                                       "+"Total : "+total,FontFactory.getFont(FontFactory.HELVETICA, 15)));
  document.add(by11);
  
  
  
  Paragraph by12 = new Paragraph(new Chunk("                                                                                       "+"Epoints Credited : "+inheader.getEpoints_credited(),FontFactory.getFont(FontFactory.HELVETICA, 15)));
  Paragraph by13 = new Paragraph(new Chunk("                                                                                       "+"Epoints Redeemed : "+inheader.getEpoints_redeemed(),FontFactory.getFont(FontFactory.HELVETICA, 15)));
  Paragraph by14 = new Paragraph(new Chunk("                                                                                       "+"Total Epoints : "+inheader.getTotal_epoints(),FontFactory.getFont(FontFactory.HELVETICA, 15)));
  document.add(by12);
  document.add(by13);
  document.add(by14);
  
  
  

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

 }

}
