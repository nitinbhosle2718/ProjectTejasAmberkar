package group3_emart;

import java.util.List;

public interface invoiceDAO 
{
	List getInvoice(List prodlist,dummy_login log);
}
