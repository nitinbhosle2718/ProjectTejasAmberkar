package group3_emart;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;



@Controller
@RequestMapping("/login.do")
public class logincontroller
{
	@Autowired
	LoginDAO logindao;
	
	
	
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView before()
	{
 		dummy_login login=new dummy_login();
		return new ModelAndView("login.definition","mylog",login);
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public String afterSubmit(
		@Valid @ModelAttribute("mylog") dummy_login login,BindingResult result,HttpServletRequest request,HttpSession session) 
	{
		//return form success view
		if(result.hasErrors())
		{
			return "login.definition";
		}
		else
		{
		dummy_login log=logindao.checkLogin(login);
		if(log.getCustomerid()==0)
			return "login.definition";
		else
		{
			session.setAttribute("login",log);
			return "redirect:/category.do";
		}
		
		
		}
	}
}