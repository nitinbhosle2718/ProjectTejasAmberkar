package group3_emart;

public interface RegisterDAO {
	void saveCustomer(customer_master ref);

}
