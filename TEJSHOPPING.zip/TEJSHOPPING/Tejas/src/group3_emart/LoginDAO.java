package group3_emart;

import java.util.List;

public interface LoginDAO {
	dummy_login checkLogin(dummy_login login);

}

